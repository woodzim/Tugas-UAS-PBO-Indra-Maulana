-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 11 Mei 2019 pada 17.42
-- Versi Server: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `transaksipulsa_rockwell`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_daftarharga`
--

CREATE TABLE `tb_daftarharga` (
  `kodenomer` varchar(50) NOT NULL,
  `kodepulsa` varchar(20) NOT NULL,
  `hargasaldo` varchar(20) NOT NULL,
  `hargajual` varchar(20) NOT NULL,
  `income` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_daftarharga`
--

INSERT INTO `tb_daftarharga` (`kodenomer`, `kodepulsa`, `hargasaldo`, `hargajual`, `income`) VALUES
('KN001', 'Axis-5K', '5500', '7000', '1500'),
('KN002', 'Axis-10K', '10500', '12000', '1500'),
('KN003', 'Axis-20K', '20500', '22000', '1500'),
('KN004', 'Axis-50K', '49000', '52000', '3000'),
('KN005', 'Axis-100K', '99000', '102000', '3000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_saldomasuk`
--

CREATE TABLE `tb_saldomasuk` (
  `kodetransaksi` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `sisasaldo` varchar(50) NOT NULL,
  `saldomasuk` varchar(50) NOT NULL,
  `totalsaldo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_saldomasuk`
--

INSERT INTO `tb_saldomasuk` (`kodetransaksi`, `tanggal`, `sisasaldo`, `saldomasuk`, `totalsaldo`) VALUES
('KT001', '2019-05-10', '0', '1000000', '1000000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_stoksaldo`
--

CREATE TABLE `tb_stoksaldo` (
  `pinsaldo` varchar(10) NOT NULL,
  `totalsaldo` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_stoksaldo`
--

INSERT INTO `tb_stoksaldo` (`pinsaldo`, `totalsaldo`) VALUES
('sal1234', 895500);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_transaksipulsa`
--

CREATE TABLE `tb_transaksipulsa` (
  `kodetransaksi` varchar(50) NOT NULL,
  `nomer` varchar(20) NOT NULL,
  `tanggal` varchar(20) NOT NULL,
  `kodepulsa` varchar(20) NOT NULL,
  `hargasaldo` varchar(20) NOT NULL,
  `hargajual` varchar(20) NOT NULL,
  `saldoawal` varchar(50) NOT NULL,
  `sisasaldo` varchar(50) NOT NULL,
  `income` varchar(50) NOT NULL,
  `pin` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_transaksipulsa`
--

INSERT INTO `tb_transaksipulsa` (`kodetransaksi`, `nomer`, `tanggal`, `kodepulsa`, `hargasaldo`, `hargajual`, `saldoawal`, `sisasaldo`, `income`, `pin`) VALUES
('KT001', '083811114444', '2019-05-10', 'Axis-100K', '99000', '102000', '1000000', '901000', '3000', 'sal1234'),
('KT002', '083877778888', '2019-05-10', 'Axis-5K', '5500', '7000', '901000', '895500', '1500', 'sal1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_daftarharga`
--
ALTER TABLE `tb_daftarharga`
  ADD PRIMARY KEY (`kodenomer`);

--
-- Indexes for table `tb_saldomasuk`
--
ALTER TABLE `tb_saldomasuk`
  ADD PRIMARY KEY (`kodetransaksi`);

--
-- Indexes for table `tb_stoksaldo`
--
ALTER TABLE `tb_stoksaldo`
  ADD PRIMARY KEY (`pinsaldo`);

--
-- Indexes for table `tb_transaksipulsa`
--
ALTER TABLE `tb_transaksipulsa`
  ADD PRIMARY KEY (`kodetransaksi`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
